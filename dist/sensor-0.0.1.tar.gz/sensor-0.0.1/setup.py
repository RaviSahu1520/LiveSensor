from setuptools import find_packages, setup

setup(
    name='sensor',
    version='0.0.1',
    author='ravi',
    author_email='ravi786modi@gmail.com',
    packages=find_packages(),

)
